package com.alk.dicreg_new;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by alexia.
 */

public class T2_listaPalavraPesquisada extends AppCompatActivity {
    private Context context;
    private ListView listView;
    private DatabaseAccess db;
    private String parametro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t6_estados);

        context = this;
        db = new DatabaseAccess(context);
        db.open();
        Intent i = getIntent();
        parametro = i.getStringExtra("TERMO");

        carregarLista();

        /*
         * Escuta qual item foi clicado e envia os detelhes do mesmo atrávés de uma intent
         **/

        listView.setOnItemClickListener(new ListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PalavraDTO palavraDTO = (PalavraDTO) listView.getItemAtPosition(position);

                String termo = palavraDTO.getTermo();
                String significado = palavraDTO.getSignificado();
                String uf = palavraDTO.getUf();

                Intent intent = new Intent(context, T8_detalhaPalavra.class);
                intent.putExtra("TERMO", termo);
                intent.putExtra("SIGNIFICADO", significado);
                intent.putExtra("ESTADO", uf);

                startActivity(intent);
            }
        });
    }

    /**
     * Preendhe uma ListView com um ArrayAdapter de palavras que atendem a pesquisa do usuário
     */

    private void carregarLista() {

        listView = findViewById(R.id.listView);

        ArrayAdapter<PalavraDTO> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, db.selectPalavras(parametro));

        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        listView.setAdapter(adapter);
        db.close();
    }

}
