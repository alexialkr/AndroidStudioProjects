package com.alk.dicreg_new;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Objects;

/**
 * Created by alexia.
 */

public class T6_listaEstados extends AppCompatActivity {

    private ListView listView;
    private String ufSelected = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t6_estados);

        Toast.makeText(this, "Por favor, selecione um ou mais estados", Toast.LENGTH_SHORT).show();
        carregarListaEstados();
    }

    /**
     * Carrega lista com estados
     */

    private void carregarListaEstados() {
        listView = findViewById(R.id.listView);

        String[] arrayListEstados = getResources().getStringArray(R.array.T04_spinner_estados);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice, arrayListEstados);

        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        listView.setAdapter(adapter);
    }


    @Override
    protected void onPause() {
        ufSelected = "";
        super.onPause();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.m6, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemClicado = item.getItemId();

        if (itemClicado == R.id.ok) {

            /*
             * Percorre a listView para verificar os itens checkados
             */

            SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();

            int cntChoice = listView.getCount();

            int i;

            for (i = 0; i < (cntChoice); i++) {

                if (sparseBooleanArray.get(i)) {

                    //noinspection StringConcatenationInLoop
                    ufSelected += "'" + listView.getItemAtPosition(i).toString() + "'" + " , ";
                }
            }

            /*                * Verifica se o usuário selecionou no mínimo um item
             * Um toast será exibido informando os itens selecionados,
             * ou informando ao usuário que selecione um item.
             */

            if (!Objects.equals(ufSelected, "")) {

                /*
                 * Remove virgula do último item selecionado
                 */

                ufSelected = ufSelected.substring(0, ufSelected.lastIndexOf(","));

                Toast.makeText(T6_listaEstados.this, ufSelected,
                        Toast.LENGTH_SHORT).show();

                Intent I = new Intent(this, T7_listaPalavraPorEstados.class);
                I.putExtra("ESTADO", ufSelected);
                startActivity(I);
            } else {
                Toast.makeText(this, "Você precisa selecionar pelo menos um estado.", Toast.LENGTH_SHORT).show();
            }
        }
        return super.onOptionsItemSelected(item);
    }
}