package com.alk.dicreg_new;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by alexia.
 */

class DatabaseAccess {
//    private static DatabaseAccess instance;
    private final SQLiteOpenHelper openHelper;
    private SQLiteDatabase database;

    /**
     * Construtor privado
     *
     */
    DatabaseAccess(Context context) {
        this.openHelper = new DatabaseOpenHelper(context);
    }


// --Commented out by Inspection START (05/06/2018 16:14):
///**
//     * Retorna um singleton de DatabaseAccess
//     *
//     */
//
//    public static DatabaseAccess getInstance(Context context) {
//        if (instance == null) {
//            instance = new DatabaseAccess(context);
//        }
//        return instance;
//    }
// --Commented out by Inspection STOP (05/06/2018 16:14)

    /**
     * Abre a conexão
     */
    void open() {
        this.database = openHelper.getWritableDatabase();
    }

    /**
     * Fecha a conexão
     */
    void close() {
        if (database != null) {
            this.database.close();
        }
    }

    /*
    Gera uma com lista todas as palavras do banco
    */
    List<PalavraDTO> selectTodasPalavras() {
        List<PalavraDTO> palavraDTOList = new ArrayList<>();

        open();
        Cursor cursor = database.rawQuery("SELECT * FROM palavras ORDER BY _termo ASC", null);

        if (cursor.moveToFirst()) {
            do {
                PalavraDTO palavra = new PalavraDTO();

                palavra.setId(cursor.getInt(0));
                palavra.setTermo(cursor.getString(1));
                palavra.setSignificado(cursor.getString(2));
                palavra.setUf(cursor.getString(3));

                palavraDTOList.add(palavra);
            }
            while (cursor.moveToNext());
        }
        database.close();
        cursor.close();
        return palavraDTOList;
    }

    /*
    Gera uma lista com todas as palavras de determinado(s) estado(s) escolhido(s) pelo usuário
    */
    List<PalavraDTO> selectPalavrasEstado(String nomeB) {
        List<PalavraDTO> palavraDTOList = new ArrayList<>();

        open();
        Cursor cursor = database.rawQuery("SELECT * FROM palavras WHERE _estado IN (" + nomeB + ") ORDER BY _termo ASC", null);

        if (cursor.moveToFirst()) {
            do {
                PalavraDTO palavra = new PalavraDTO();

                palavra.setId(cursor.getInt(0));
                palavra.setTermo(cursor.getString(1));
                palavra.setSignificado(cursor.getString(2));
                palavra.setUf(cursor.getString(3));

                palavraDTOList.add(palavra);
            }
            while (cursor.moveToNext());
        }
        database.close();
        cursor.close();
        return palavraDTOList;
    }

    /*
    Gera uma lista com as palavras que possuem o texto pesquisado pelo usuário.
    */
    List<PalavraDTO> selectPalavras(String nomeB) {
        List<PalavraDTO> palavraDTOList = new ArrayList<>();

        open();

        Cursor cursor = database.rawQuery("SELECT * FROM palavras WHERE _termo LIKE '%" + nomeB + "%' ORDER BY _termo COLLATE LOCALIZED ASC", null);

        //Cursor cursor = database.query("palavras",new String[]{"_termo"},"_termo LIKE ?",new String[]{nomeB}, null,null, null);

        if (cursor.moveToFirst()) {
            do {
                PalavraDTO palavra = new PalavraDTO();

                palavra.setId(cursor.getInt(0));
                palavra.setTermo(cursor.getString(1));
                palavra.setSignificado(cursor.getString(2));
                palavra.setUf(cursor.getString(3));

                palavraDTOList.add(palavra);
            }
            while (cursor.moveToNext());
        }
        database.close();
        cursor.close();
        return palavraDTOList;
    }

}