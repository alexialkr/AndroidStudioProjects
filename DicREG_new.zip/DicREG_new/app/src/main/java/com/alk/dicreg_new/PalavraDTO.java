package com.alk.dicreg_new;

/**
 * Created by alexia.
 */

class PalavraDTO {
    private int id;
    private String termo, significado, uf;


    // --Commented out by Inspection START (05/06/2018 16:12):
//    public int getId() {
//        return id;
//    }
// --Commented out by Inspection STOP (05/06/2018 16:12)
    public void setId(int id) {
        this.id = id;
    }

    String getTermo() {
        return termo;
    }

    void setTermo(String termo) {
        this.termo = termo;
    }

    String getSignificado() {
        return significado;
    }

    void setSignificado(String significado) {
        this.significado = significado;
    }

    String getUf() {
        return uf;
    }

    void setUf(String uf) {
        this.uf = uf;
    }

    @Override
    public String toString() {
        return this.termo;
    }

}
