package com.alk.dicreg_new;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by alexia.
 */

public class T5_sobre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t5);
    }
}
