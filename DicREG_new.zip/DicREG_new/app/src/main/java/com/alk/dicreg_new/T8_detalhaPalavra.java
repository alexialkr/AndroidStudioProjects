package com.alk.dicreg_new;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by alexia.
 */

public class T8_detalhaPalavra extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t8);

        TextView txtTermo = findViewById(R.id.T8_Palavra);
        TextView txtSignificado = findViewById(R.id.T8_Significado);
        TextView txtUf = findViewById(R.id.T8_Uf);

        Intent i = getIntent();
        final String termo = i.getStringExtra("TERMO");
        final String significado = i.getStringExtra("SIGNIFICADO");
        final String estado = i.getStringExtra("ESTADO");

        txtTermo.setText(termo);
        txtSignificado.setText(significado);
        txtUf.setText(estado);

        final String prefixUF;

        switch (estado) {
            case "Acre":
            case "Amapá":
            case "Amazonas":
            case "Ceará":
            case "Distrito Federal":
            case "Maranhão":
            case "Pará":
            case "Paraná":
            case "Piauí":
            case "Rio de Janeiro":
            case "Rio Grande do Norte":
            case "Rio Grande do Sul":
            case "Sergipe":
            case "Tocantins":
                prefixUF = "No";
                break;
            case "Bahia":
            case "Paraíba":
                prefixUF = "Na";
                break;
            default:
                prefixUF = "Em";
                break;
        }

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");

                intent.putExtra(Intent.EXTRA_TEXT, "Hey, você sabe o que significa \n'" + termo + "'?\n \n" +
                        prefixUF + " " + estado + ", ela significa: " + significado + "\n" +
                        "\nVeja o significado dessa e outras palavras e expressões baixando o Dicionário Regional Brasileiro.\n" +
                        "(Clique aqui para baixar na Play Store)");

                startActivity(Intent.createChooser(intent, "Onde você deseja compartilhar?"));
            }
        });

    }

}