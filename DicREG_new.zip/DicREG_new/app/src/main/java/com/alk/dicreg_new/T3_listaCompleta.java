package com.alk.dicreg_new;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by alexia.
 */

public class T3_listaCompleta extends AppCompatActivity {
    private Context context;
    private ListView listView;
    private DatabaseAccess db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t3_lista);
        context = this;
        db = new DatabaseAccess(context);

        FloatingActionButton fab = findViewById(R.id.T3_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, T4_sugestaoNovaPalavra.class);
                startActivity(intent);
            }
        });

        carregarListaCompleta();

        /*Escuta qual item foi clicado e envia os detelhes do mesmo atrávés de uma intent
        * */

        listView.setOnItemClickListener(new ListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PalavraDTO palavraDTO = (PalavraDTO) listView.getItemAtPosition(position);

                String termo = palavraDTO.getTermo();
                String significado = palavraDTO.getSignificado();
                String uf = palavraDTO.getUf();

                Intent intent = new Intent(context, T8_detalhaPalavra.class);
                intent.putExtra("TERMO", termo);
                intent.putExtra("SIGNIFICADO", significado);
                intent.putExtra("ESTADO", uf);

                startActivity(intent);
            }
        });

    }

    /**
     * Carrega uma lista todas as palavras do banco
     */

    private void carregarListaCompleta() {
        db.open();

        listView = findViewById(R.id.T3_listView);

        ArrayAdapter<PalavraDTO> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, db.selectTodasPalavras());

        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        listView.setAdapter(adapter);

        db.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.m4, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemClicado = item.getItemId();
        if (itemClicado == (R.id.m4_filter)) {
            Intent intent = new Intent(this, T6_listaEstados.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}