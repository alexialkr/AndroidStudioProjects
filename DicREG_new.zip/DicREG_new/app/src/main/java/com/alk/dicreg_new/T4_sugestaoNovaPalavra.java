package com.alk.dicreg_new;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.Objects;

/**
 * Created by alexia.
 */

public class T4_sugestaoNovaPalavra extends AppCompatActivity {

    private TextInputEditText editIncluir;
    private Spinner spinnerEstados;
    private TextInputEditText editSignificado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t4);
        //Integração Java e XML
        editIncluir = findViewById(R.id.T4_Incluir);
        spinnerEstados = findViewById(R.id.T4_SpinEstados);
        editSignificado = findViewById(R.id.T4_AddSignificado);
    }//fim do onCreate

    public void enviar(View v) {
        String palavraDig = Objects.requireNonNull(editIncluir.getText()).toString();
        String estadoDig = spinnerEstados.getSelectedItem().toString();
        String significadoDig = Objects.requireNonNull(editSignificado.getText()).toString();
        if ((!Objects.equals(palavraDig, "")) && (!Objects.equals(significadoDig, ""))) {
            String uriText =
                    "mailto:18devak@gmail.com" +
                            "?subject=" + Uri.encode("SUGESTÃO DE NOVA PALAVRA - " + palavraDig) +
                            "&body=" + Uri.encode("Olá, acho que está palavra ainda não foi adicionada ao Dicionário Regional " +
                            "Brasileiro, ou acredito que ela possua um outro significado diferente do existente no app!\n"
                            + "\nPalavra ou expressão: " + palavraDig
                            + "\nEstado: " + estadoDig
                            + "\nSignificado da palavra ou expressão: " + significadoDig);
            Uri uri = Uri.parse(uriText);
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
            emailIntent.setData(uri);
            startActivity(Intent.createChooser(emailIntent, "Selecione seu app de e-mail preferido"));
        } else {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.m1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemClicado = item.getItemId();
        if (itemClicado == (R.id.M1_ItemSair)) {
            this.finish(); // só fecha a activity atual
        } else if (itemClicado == (R.id.M1_ItemListaComp)) {
            Intent i = new Intent(this, T3_listaCompleta.class);
            startActivity(i);
        } else if (itemClicado == (R.id.M1_ItemEstados)) {
            Intent i = new Intent(this, T6_listaEstados.class);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPause() {
        editIncluir.setText("");
        editSignificado.setText("");
        editIncluir.requestFocus();
        super.onPause();
    }
}//fim da classe