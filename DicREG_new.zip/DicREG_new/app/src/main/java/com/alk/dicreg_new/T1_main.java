package com.alk.dicreg_new;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.Objects;

/**
 * Created by alexia.
 */

public class T1_main extends AppCompatActivity {
    private TextInputEditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t1);
        editText = findViewById(R.id.T1_Search);
    }

    /**
     * captura texto informado pelo usuário e envia através de uma intent
     */

    public void SearchWord(View view) {
        String wordTiped = Objects.requireNonNull(editText.getText()).toString();

        if (!Objects.equals(wordTiped, "")) {
            if ((wordTiped.charAt(wordTiped.length() - 1) == '.')) {
                wordTiped = wordTiped.substring(0, wordTiped.lastIndexOf("."));
            }
            if ((wordTiped.charAt(wordTiped.length() - 1) == ' ')) {
                wordTiped = wordTiped.substring(0, wordTiped.lastIndexOf(" "));
            }

            Intent intent = new Intent(this, T2_listaPalavraPesquisada.class);
            intent.putExtra("TERMO", wordTiped);
            startActivity(intent);
        } else {
            Intent intent = new Intent(this, T3_listaCompleta.class);
            startActivity(intent);
        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.m3, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemClicado = item.getItemId();

        if (itemClicado == R.id.M3_ItemListaComp) {
            Intent i = new Intent(this, T3_listaCompleta.class);
            startActivity(i);

        }

        if (itemClicado == R.id.M3_ItemFiltrar) {
            Intent i = new Intent(this, T6_listaEstados.class);
            startActivity(i);
        }

        if (itemClicado == R.id.M3_ItemAddP) {
            Intent i = new Intent(this, T4_sugestaoNovaPalavra.class);
            startActivity(i);
        }

        if (itemClicado == R.id.M3_ItemSobre) {
            Intent i = new Intent(this, T5_sobre.class);
            startActivity(i);
        }

        if (itemClicado == R.id.M3_ItemSair) {
            this.finish(); // esta fechando uma activity por vez ao invés do app completo(corrigir)
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPause() {
        editText.setText("");
        super.onPause();
    }

    @Override
    protected void onResume() {
        editText.requestFocus();
        super.onResume();
    }
}
